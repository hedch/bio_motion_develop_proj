using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class arm_move : MonoBehaviour
{
    GameObject head;
    GameObject[] l_arm_joint = new GameObject[5];
    GameObject[] r_arm_joint = new GameObject[5];

    public float[] left_arm = new float[5] { 0, 0, 0, 0, 0 };
    public float[] right_arm = new float[5] { 0, 0, 0, 0, 0 };
    int[] arm_axis = new int[] { 1, 2, 0, 1, 2};

    void Start()
    {
        ini_config();
    }

    // Update is called once per frame
    void Update()
    {
        for (int i = 0; i < 5; i++) {
            float[] angle = new float[3] { 0, 0, 0 };
            angle[arm_axis[i]] = left_arm[i];
            l_arm_joint[i].transform.localEulerAngles = new Vector3(angle[0], angle[1], angle[2]);
            angle = new float[3] { 0, 0, 0 };
            angle[arm_axis[i]] = right_arm[i];
            r_arm_joint[i].transform.localEulerAngles = new Vector3(angle[0], angle[1], angle[2]);
        }

    }
    void ini_config() {
        head = GameObject.Find("head");
        l_arm_joint[1] = head.transform.Find("shoulder/left/joint1").gameObject;
        l_arm_joint[2] = l_arm_joint[1].transform.Find("joint2").gameObject;
        l_arm_joint[0] = l_arm_joint[2].transform.Find("shoulder_joint/joint0").gameObject;
        l_arm_joint[4] = l_arm_joint[0].transform.Find("arm0/elbow_joint/joint4").gameObject;
        l_arm_joint[3] = l_arm_joint[4].transform.Find("joint3").gameObject;
        r_arm_joint[1] = head.transform.Find("shoulder/right/joint1").gameObject;
        r_arm_joint[2] = r_arm_joint[1].transform.Find("joint2").gameObject;
        r_arm_joint[0] = r_arm_joint[2].transform.Find("shoulder_joint/joint0").gameObject;
        r_arm_joint[4] = r_arm_joint[0].transform.Find("arm0/elbow_joint/joint4").gameObject;
        r_arm_joint[3] = r_arm_joint[4].transform.Find("joint3").gameObject;
    }
}

